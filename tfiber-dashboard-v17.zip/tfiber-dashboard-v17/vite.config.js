import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// base './' lets the built site run from any sub-folder or static host.
//
// The dashboard calls the device-status API on its own address (/api/device-status); this proxy forwards it to
// DEVICE_API_URL (set in .env). That avoids browser CORS / mixed-content problems and keeps the API address out of the page.
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const target = env.DEVICE_API_URL || 'http://172.28.0.25:8000';
  const proxy = {
    '/api/device-status': {
      target,
      changeOrigin: true,
      rewrite: (p) => p.replace(/^\/api/, ''),
      // Vite 2 only logs proxy errors and leaves the browser waiting; answer straight away so the table shows "Error" instead of hanging
      configure: (proxy) => {
        proxy.on('error', (err, req, res) => {
          if (res && typeof res.writeHead === 'function' && !res.headersSent) {
            res.writeHead(502, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ detail: `Device API unreachable (${err.code || err.message}) at ${target}` }));
          }
        });
      },
    },
  };
  return { base: './', plugins: [react()], server: { proxy }, preview: { proxy } };
});
