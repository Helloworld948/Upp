/*
 * Stand-in for the services API, for testing without the real network:
 *   node scripts/mock-records-api.cjs path/to/saved_response.json [--port 8122]
 * serves the file at GET /api/services/latest/export. Then set RECORDS_API_URL=http://127.0.0.1:8122 in .env.
 */
var http = require('http'); var fs = require('fs');
var file = process.argv[2]; var port = 8122;
var i = process.argv.indexOf('--port'); if (i > 0) port = +process.argv[i + 1];
if (!file) { console.error('usage: node scripts/mock-records-api.cjs <response.json> [--port 8122]'); process.exit(1); }
http.createServer(function (req, res) {
  if (req.url.split('?')[0] !== '/api/services/latest/export') { res.writeHead(404); return res.end('not found'); }
  setTimeout(function () { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(fs.readFileSync(file)); }, 400);
}).listen(port, function () { console.log('[mock] services API on http://127.0.0.1:' + port); });
