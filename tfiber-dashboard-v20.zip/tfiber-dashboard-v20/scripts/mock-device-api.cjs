/*
 * Stand-in for the device-status API, for demos / testing without the real network.
 *   node scripts/mock-device-api.cjs [--port 8000]
 * then set DEVICE_API_URL=http://127.0.0.1:8000 in .env and restart `npm start`.
 * Same shape as the real response. By the last character of the serial: C/D -> DOWN, E -> not found, F -> HTTP 500, others -> UP.
 */
var http = require('http');
var port = 8000;
var i = process.argv.indexOf('--port');
if (i > 0) port = +process.argv[i + 1];

var strict = process.argv.indexOf('--strict') > 0; // --strict: answer 503 when a request arrives while another is still running
var active = 0;

http.createServer(function (req, res) {
  if (req.method !== 'POST' || req.url.split('?')[0] !== '/device-status') { res.writeHead(404); return res.end('not found'); }
  if (strict && active > 0) { res.writeHead(503, { 'Content-Type': 'application/json' }); return res.end('{"detail":"busy"}'); }
  active += 1;
  var body = '';
  req.on('data', function (c) { body += c; });
  req.on('end', function () {
    var id = '';
    try { id = String(JSON.parse(body).identifier || ''); } catch (e) { active -= 1; res.writeHead(400); return res.end('{"success":false}'); }
    var last = id.slice(-1).toUpperCase();
    setTimeout(function () {
      if (last === 'F') { active -= 1; res.writeHead(500, { 'Content-Type': 'application/json' }); return res.end('{"detail":"mock server error"}'); }
      var out = { success: true, identifier: id, identifier_type: 'serial', request_type: 'status', match_count: 1, results: [] };
      if (last === 'E') { out.success = false; out.match_count = 0; }
      else {
        var n = id.split('').reduce(function (a, c) { return a + c.charCodeAt(0); }, 0);
        var up = !(last === 'C' || last === 'D');
        out.results.push({
          source: 'tejas_ont', vendor: 'TEJAS', device_type: 'ONT', serial: id, package: 'B', ip: null, lgd: null,
          hostname: 'SRPCVMLXOLT001', site_name: 'MOCK SITE', connected_olt_ip: '172.26.137.57', connected_olt_lgd: null,
          district: null, mandal: null, gp: null, gp_type: null, ticket_id: null, tt_start_time: null, cause_code: null, success: true,
          status: up ? 'ONT(' + id + ') is UP, TxPower value : ' + (2 + (n % 20) / 10).toFixed(3) + ', RxPower value : -' + (8 + (n % 90) / 10).toFixed(3)
                     : 'ONT(' + id + ') is DOWN'
        });
      }
      active -= 1;
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(out));
    }, 100 + (id.length * 13) % 200);
  });
}).listen(port, function () { console.log('[mock] device-status API on http://127.0.0.1:' + port + '/device-status'); });
