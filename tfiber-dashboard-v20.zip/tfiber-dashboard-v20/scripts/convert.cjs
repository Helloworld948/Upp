/*
 * Daily Excel report -> dashboard data.
 *
 *   node scripts/convert.cjs                 convert data-source/daily_report.xlsx once
 *   node scripts/convert.cjs --watch         convert now, then again every time the file is replaced
 *   node scripts/convert.cjs --in <file> --out <folder>
 *
 * Writes three files into the output folder (default public/data):
 *   connections.json        rows of the sheet "Total Connections Detailed Data" (columnar)
 *   summary_reference.json  figures read from the sheet "Summary dd-Mmm-yyyy"
 *   meta.json               when it was generated; the open dashboard polls this and reloads itself
 * Nothing is overwritten unless the whole conversion succeeds.
 * (Plain CommonJS and conservative syntax so it also runs on older Node versions.)
 */
var fs = require('fs');
var path = require('path');
var XLSX = require('xlsx');

var ROOT = path.resolve(__dirname, '..');
var DEFAULT_IN = path.join(ROOT, 'data-source', 'daily_report.xlsx');
var DEFAULT_OUT = path.join(ROOT, 'public', 'data');

var MAIN_SHEET = 'Total Connections Detailed Data';
var HEADER_ROW = 1; // 0-based: the header is on the 2nd row of the sheet
var SUMMARY_SHEET = /^Summary\s+(\d{1,2})-([A-Za-z]{3})-(\d{4})$/;
var MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

// Columns exported (names as in the workbook after line breaks/extra spaces are removed).
// Contact names / numbers are deliberately NOT exported.
var COLUMNS = [
  'GI Name', 'Department', 'Connection Catogory', 'PO Status', 'LCO/MSI/TSP', 'LCO Operator Name', 'Litup',
  'Package', 'District', 'Mandal Name', 'Solution Type', 'Delivery Mode (Switch/ Router/ ONT/Wireless)',
  'Service Provisioned (Yes/NO)', 'SAC Form Status', 'Disconnection Status',
  'PO Num', 'GI /GP Name', 'GP/ GI ONT LGD Code2', 'ONT Serail number', 'OLT IP Address', 'Service ID',
  'PO /Order date', 'Service Delivered(Litup date) (Date;Time)'
];
var DATE_COLUMNS = { 'PO /Order date': 1, 'Service Delivered(Litup date) (Date;Time)': 1 };
// Without these the dashboard cannot work, so the conversion stops (alternative spellings allowed).
var REQUIRED = [
  ['Connection Catogory', 'Connection Category'], ['PO Status'], ['Litup'], ['Service Provisioned (Yes/NO)'],
  ['District'], ['Package'], ['LCO Operator Name']
];

function clean(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }
function pad(n) { return (n < 10 ? '0' : '') + n; }

function cellText(cell, isDate) {
  if (!cell || cell.v === undefined || cell.v === null) return null;
  if (cell.t === 'e') return clean(cell.w || '#N/A');           // Excel error such as #N/A
  if (cell.t === 'n' && isDate) {
    var d = XLSX.SSF.parse_date_code(cell.v);
    if (d && d.y > 1900) {
      var s = d.y + '-' + pad(d.m) + '-' + pad(d.d);
      return d.H || d.M || d.S ? s + ' ' + pad(d.H) + ':' + pad(d.M) + ':' + pad(d.S) : s;
    }
  }
  var t = clean(cell.v);
  return t === '' ? null : t;
}

function readSheetNames(file) {
  return XLSX.readFile(file, { bookSheets: true }).SheetNames;
}

function pickSummarySheet(names) {
  var best = null;
  names.forEach(function (n) {
    var m = SUMMARY_SHEET.exec(n.trim());
    if (!m) return;
    var mi = MONTHS.indexOf(m[2].toLowerCase());
    if (mi < 0) return;
    var stamp = +m[3] * 10000 + (mi + 1) * 100 + +m[1];
    if (!best || stamp > best.stamp) best = { name: n, stamp: stamp, day: +m[1], mon: mi, year: +m[3] };
  });
  return best;
}

function parseSummary(ws, info, mainRows) {
  var ref = {
    asOf: info.year + '-' + pad(info.mon + 1) + '-' + pad(info.day),
    asOfLabel: info.day + ' ' + (MONTHS[info.mon].charAt(0).toUpperCase() + MONTHS[info.mon].slice(1)) + ' ' + info.year,
    source: "Workbook sheet '" + info.name + "'",
    mainSheetRecords: mainRows
  };
  var range = XLSX.utils.decode_range(ws['!ref']);
  for (var r = range.s.r; r <= Math.min(range.e.r, 15); r++) {
    var head = ws[XLSX.utils.encode_cell({ r: r, c: 1 })];
    if (head && clean(head.v).toLowerCase() === 'total user connectivity') {
      var keys = ['total', 'po', 'litUp', 'yetToLitUp', 'serviceProvisioned', 'serviceYetToProvision', 'sacReceived', 'sacYetToReceive', 'disconnected'];
      var ok = true;
      keys.forEach(function (k, i) {
        var c = ws[XLSX.utils.encode_cell({ r: r + 1, c: 1 + i })];
        if (c && typeof c.v === 'number') ref[k] = c.v; else ok = false;
      });
      var poc = ws[XLSX.utils.encode_cell({ r: r + 1, c: 10 })];
      if (poc && typeof poc.v === 'number') ref.poc = poc.v; else ok = false;
      if (ok) return ref;
    }
  }
  return null;
}

function convert(opts) {
  opts = opts || {};
  var input = path.resolve(opts.input || DEFAULT_IN);
  var outDir = path.resolve(opts.out || DEFAULT_OUT);
  if (!fs.existsSync(input)) throw new Error('Excel file not found: ' + input);

  var names = readSheetNames(input);
  if (names.indexOf(MAIN_SHEET) < 0) throw new Error('Sheet "' + MAIN_SHEET + '" not found. Sheets in the file: ' + names.slice(0, 12).join(', ') + (names.length > 12 ? ', ...' : ''));
  var summaryInfo = pickSummarySheet(names);

  var wanted = [MAIN_SHEET].concat(summaryInfo ? [summaryInfo.name] : []);
  var wb = XLSX.readFile(input, { sheets: wanted, cellStyles: false, cellNF: false });
  var ws = wb.Sheets[MAIN_SHEET];
  var range = XLSX.utils.decode_range(ws['!ref']);

  // locate columns by header text
  var colIndex = {};
  for (var c = range.s.c; c <= range.e.c; c++) {
    var h = ws[XLSX.utils.encode_cell({ r: HEADER_ROW, c: c })];
    if (h) { var name = clean(h.v); if (name && colIndex[name] === undefined) colIndex[name] = c; }
  }
  var missing = [];
  REQUIRED.forEach(function (alts) {
    if (!alts.some(function (a) { return colIndex[a] !== undefined; })) missing.push(alts[0]);
  });
  if (missing.length) throw new Error('Required column(s) not found in "' + MAIN_SHEET + '": ' + missing.join(', ') + '. Check that the header is on row ' + (HEADER_ROW + 1) + ' and the names were not changed.');

  var used = COLUMNS.filter(function (n) {
    if (colIndex[n] !== undefined) return true;
    if (n === 'Connection Catogory' && colIndex['Connection Category'] !== undefined) return true;
    return false;
  });
  var usedSource = used.map(function (n) { return colIndex[n] !== undefined ? n : 'Connection Category'; });
  var optionalMissing = COLUMNS.filter(function (n) { return used.indexOf(n) < 0 && n !== 'Connection Catogory'; });

  var rows = [];
  for (var r = HEADER_ROW + 1; r <= range.e.r; r++) {
    var row = [], any = false;
    for (var i = 0; i < usedSource.length; i++) {
      var cell = ws[XLSX.utils.encode_cell({ r: r, c: colIndex[usedSource[i]] })];
      var v = cellText(cell, !!DATE_COLUMNS[usedSource[i]]);
      if (v !== null) any = true;
      row.push(v);
    }
    if (any) rows.push(row);
  }
  if (!rows.length) throw new Error('No data rows found in "' + MAIN_SHEET + '".');

  var reference = null, warnings = [];
  if (summaryInfo) reference = parseSummary(wb.Sheets[summaryInfo.name], summaryInfo, rows.length);
  if (!reference) warnings.push('Summary sheet not found or not readable: keeping the previous summary_reference.json, so the "Verified" badges may be out of date.');
  if (optionalMissing.length) warnings.push('Optional columns not in the file (left out): ' + optionalMissing.join(', '));

  // write atomically: temp file first, then rename
  fs.mkdirSync(outDir, { recursive: true });
  function put(name, obj) {
    var tmp = path.join(outDir, name + '.tmp'), dest = path.join(outDir, name);
    fs.writeFileSync(tmp, JSON.stringify(obj));
    fs.renameSync(tmp, dest);
  }
  put('connections.json', { columns: usedSource, rows: rows });
  if (reference) put('summary_reference.json', reference);
  var st = fs.statSync(input);
  var meta = {
    generatedAt: new Date().toISOString(),
    sourceFile: path.basename(input),
    sourceModified: st.mtime.toISOString(),
    records: rows.length,
    asOfLabel: reference ? reference.asOfLabel : null
  };
  put('meta.json', meta);
  return { meta: meta, reference: reference, warnings: warnings, outDir: outDir };
}

function report(res) {
  console.log('[data] ' + res.meta.records.toLocaleString() + ' records' + (res.meta.asOfLabel ? ' · report date ' + res.meta.asOfLabel : '') + ' -> ' + res.outDir);
  res.warnings.forEach(function (w) { console.log('[data] warning: ' + w); });
}

/** Converts now and again whenever the Excel file is added or replaced. Returns a stop() function. */
function watch(opts) {
  opts = opts || {};
  var input = path.resolve(opts.input || DEFAULT_IN);
  var dir = path.dirname(input), base = path.basename(input).toLowerCase();
  var timer = null, running = false, rerun = false;

  function sizeStable(cb) {            // wait until a copy in progress has finished
    var last = -1, n = 0;
    (function tick() {
      var s = -2;
      try { s = fs.statSync(input).size; } catch (e) { return cb(false); }
      if (s === last && s > 0) return cb(true);
      last = s;
      if (++n > 60) return cb(false);
      setTimeout(tick, 1000);
    })();
  }
  function run(attempt) {
    if (running) { rerun = true; return; }
    running = true;
    sizeStable(function (ok) {
      if (!ok) { running = false; return; }
      try {
        report(convert(opts));
      } catch (e) {
        if (/EBUSY|EPERM|EACCES|ENOENT|Unexpected end|Corrupt|Invalid|zip/i.test(String(e && (e.code || e.message))) && (attempt || 0) < 8) {
          running = false;
          return setTimeout(function () { run((attempt || 0) + 1); }, 3000); // file still locked by Excel/copy
        }
        console.log('[data] ERROR: ' + e.message + '\n[data] The dashboard keeps showing the previous data.');
      }
      running = false;
      if (rerun) { rerun = false; run(0); }
    });
  }
  function onChange(file) {
    if (!file) return;
    var f = String(file).toLowerCase();
    if (f !== base || f.indexOf('~$') === 0) return;
    clearTimeout(timer);
    timer = setTimeout(function () { run(0); }, 1500);
  }

  fs.mkdirSync(dir, { recursive: true });
  var w = fs.watch(dir, function (evt, file) { onChange(file); });
  console.log('[data] watching ' + input + ' (replace the file to update the dashboard)');
  if (fs.existsSync(input)) run(0); else console.log('[data] no Excel file yet: put the daily report at ' + input);
  return function stop() { try { w.close(); } catch (e) { /* ignore */ } };
}

module.exports = { convert: convert, watch: watch, report: report, DEFAULT_IN: DEFAULT_IN, DEFAULT_OUT: DEFAULT_OUT };

if (require.main === module) {
  var args = process.argv.slice(2), o = {};
  for (var a = 0; a < args.length; a++) {
    if (args[a] === '--in') o.input = args[++a];
    else if (args[a] === '--out') o.out = args[++a];
    else if (args[a] === '--watch') o.watch = true;
  }
  if (o.watch) watch(o);
  else {
    try { report(convert(o)); } catch (e) { console.error('[data] ERROR: ' + e.message); process.exit(1); }
  }
}
