Put the daily Excel report in this folder with EXACTLY this name:

    daily_report.xlsx

It must contain the sheet "Total Connections Detailed Data" (header on row 2) and a sheet named
"Summary dd-Mmm-yyyy" (for example "Summary 16-Sep-2026"). If several Summary sheets exist, the latest date is used.

With "npm start" (or "npm run prod") running, replacing this file is enough: the dashboard data is rebuilt
automatically and the open page refreshes itself within about 30 seconds.
