# T-Fiber End-User Connectivity Dashboard

React 18 + Highcharts 11, built with Vite. Frontend only: no backend, no database.
Data comes from the daily Excel report, converted to static JSON by a small Node script.

## Daily update (the normal routine)
1. Save the daily report as `data-source/daily_report.xlsx` (always the same name; replace the old file).
2. That is all, as long as `npm start` is running: the file is converted automatically and the open dashboard
   reloads itself within about 30 seconds (a green "New data loaded" banner appears; filters stay as they are).

## Run
    npm install
    npm start        # converts the Excel file, watches it for changes and starts the dashboard at http://localhost:3000
    npm run prod     # builds the site, converts into dist/data, watches the Excel file, serves dist/ at http://<this-pc>:4173

Other commands: `npm run data` (convert once), `npm run data:watch` (watch only), `npm run build`, `npm run preview`.
`npm start` and `npm run prod` also work when there is no Excel file yet: they use the JSON already in `public/data/`.

## What the Excel file must contain
- Sheet **Total Connections Detailed Data**, header on row 2 (same column names as the current report).
- A sheet named **Summary dd-Mmm-yyyy**, e.g. `Summary 16-Sep-2026`; if there are several, the latest date is used.
  Its first figures row (starting "Total user connectivity") feeds the "Verified" badges on the KPI cards and the
  "as on" date shown in the header.
- If a required column is missing or renamed, or the sheet is not found, the converter prints a clear error and the
  dashboard keeps showing the previous data (nothing is overwritten unless the whole conversion succeeds).

## Files written by the converter (`public/data/`, or `dist/data/` for `npm run prod`)
    connections.json        rows of the main sheet (selected columns, columnar; contact names/numbers are not exported)
    summary_reference.json  figures from the Summary sheet
    meta.json               generation time; the open page checks it every 30 s (`refreshSeconds` in src/config.js)

## Structure
    data-source/daily_report.xlsx   the daily report goes here (fixed name)
    scripts/convert.cjs             Excel -> JSON converter (also the watcher)
    scripts/dev.cjs                 npm start / npm run prod
    src/config.js        scope, SAC "received" statuses, Top-N values, refresh interval, filter list
    src/lib/mapper.js    original column names (incl. "Connection Catogory"), cleaning, alias tables
    src/lib/calc.js      filters, KPI rules, chart aggregation (pure functions)
    src/lib/export.js    CSV / Excel / PDF export of the Records table
    src/hooks.js         data loading + auto refresh (replace with an API call later; nothing else changes)
    src/components/      MultiSelect, KpiCard, ChartCard, RecordsTable, charts, tooltips

## Records table data source (v2.0)
The Records table no longer reads the Excel file: it loads `GET /api/services/latest/export` (`{ table, count, data: [...] }`).
- The browser calls `/api/services/latest/export`; the dashboard server forwards it to `RECORDS_API_URL` in `.env`
  (`http://172.28.0.26:8122`). That PC must be able to reach it. Restart `npm start` after changing `.env`.
- It reloads when the page opens, every 5 minutes (`recordsRefreshSeconds` in `src/config.js`) and on the **Reload data** button.
  If a refresh fails the previous rows stay on screen with a notice.
- Column mapping (API name -> table): PO Number, GI /GP Name, District, Mandal Name, Connection Catogiry, PO Status, Service ID,
  final_status (Monitoring Status), Order Status, ONT Serail number, OLT IP Address, GP/ GI ONT LGD Code, Package,
  LCO Operator Name, Litup, Service Provisioned, SAC Form Status, Service Delivered (Lit-Up date). Mapping lives in `src/lib/mapper.js`.
- KPIs and charts still come from the Excel report. The dashboard filters (district, package, department, ...) also filter the table;
  Solution Type / Delivery Mode do not exist in the API, so they are ignored there.
- Test without the network: `node scripts/mock-records-api.cjs saved_response.json` and set `RECORDS_API_URL=http://127.0.0.1:8122`.

## Records table
Filter by ONT Serial Number, OLT IP Address, Service ID, GI / GP Name, GP/GI ONT LGD Code and PO Num (text, partial
match; comma-separated values match any). It respects the global filters. Export downloads every matching row as
CSV or Excel; PDF is capped at 3,000 rows.

## ONT live status (v1.7)
The Records table has an **ONT Status** column. For every ONT serial starting with `TJ` the dashboard calls
`POST /device-status` with `{"identifier":"<serial>"}` and shows `results[0].status` (UP / DOWN / other, plus Tx/Rx power).
- Rows on screen are checked automatically; **Check ONT status (N)** checks every row matching the current filters (Stop button available).
- Filter by status (All / UP / DOWN / Other / Error-not found / Not checked) and sort by it. CSV / Excel / PDF exports include the status.
- Results are cached for 5 minutes (errors 20 s); requests run one at a time (150 ms apart); failed calls are retried up to 3 times before showing Error.
- The browser calls `/api/device-status`; Vite forwards it to the device API, which avoids CORS and mixed-content problems.
  The address is set in `.env` (`DEVICE_API_URL=http://172.28.0.25:8000`); restart `npm start` after changing it.
  **The PC running `npm start` / `npm run prod` must be able to reach that address.**
- Other settings in `src/config.js`: `statusSerialPrefixes`, `statusConcurrency`, `statusGapMs`, `statusRetries`, `statusTtlSeconds`, `statusTimeoutSeconds`.
- Offline test: `npm run mock:api` starts a fake device API on port 8000 (set `DEVICE_API_URL=http://127.0.0.1:8000`).

## KPI rules
With the "PO only" switch they match the Summary sheet:
- Lit-Up = PO and Litup Yes; Yet to Lit-Up = PO and Litup No/blank
- Service Provisioned = PO, Lit-Up, and (Yes or Disconnected); Service Yet to Provision = Lit-Up minus Provisioned
- SAC Form Received = SAC Form Status in `sacReceived` (src/config.js); Yet to Receive = Service Provisioned minus SAC Received
- Disconnected = PO and Disconnection Status Yes
- "POS" in the original brief is treated as POC.

## Open item
SAC Form Received computes to 1,600 vs 1,606 in the 16-Sep summary (yet to receive 1,454 vs 1,448). The summary seems to
include a manual adjustment; the business team must confirm which statuses count as "received".
