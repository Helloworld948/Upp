import { fmt } from '../lib/theme';

const ICONS = {
  users: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75',
  layers: 'M12 2L2 7l10 5 10-5-10-5z M2 17l10 5 10-5 M2 12l10 5 10-5',
  repeat: 'M17 1l4 4-4 4 M3 11V9a4 4 0 0 1 4-4h14 M7 23l-4-4 4-4 M21 13v2a4 4 0 0 1-4 4H3',
  zap: 'M13 2L3 14h9l-1 8 10-12h-9l1-8z',
  clock: 'M12 6v6l4 2 M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20',
  check: 'M22 11.08V12a10 10 0 1 1-5.93-9.14 M22 4L12 14.01l-3-3',
  hourglass: 'M5 22h14 M5 2h14 M17 22v-4.17a2 2 0 0 0-.59-1.42L12 12l-4.41 4.41A2 2 0 0 0 7 17.83V22 M7 2v4.17a2 2 0 0 0 .59 1.42L12 12l4.41-4.41A2 2 0 0 0 17 6.17V2',
  file: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M9 15l2 2 4-4',
  filePending: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M9 15h6',
  unplug: 'M19 5l3-3 M2 22l3-3 M6.3 20.3a2.4 2.4 0 0 0 3.4 0L12 18l-6-6-2.3 2.3a2.4 2.4 0 0 0 0 3.4z M7.5 13.5L10 11 M10.5 16.5L13 14 M12 6l6 6 2.3-2.3a2.4 2.4 0 0 0 0-3.4l-2.6-2.6a2.4 2.4 0 0 0-3.4 0z',
};

export const Icon = ({ name, size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {ICONS[name].split(' M').map((d, i) => <path key={i} d={(i ? 'M' : '') + d} />)}
  </svg>
);

export default function KpiCard({ label, value, tone = 'primary', icon, info, pct, pctOf, reference, showReference }) {
  const p = pct == null || !isFinite(pct) ? null : Math.max(0, Math.min(100, pct));
  let badge = null;
  if (showReference && reference != null) {
    const diff = value - reference;
    badge = diff === 0
      ? <span className="badge ok" data-tip="Matches Summary 16-Sep-2026">✓ Verified</span>
      : <span className="badge warn" data-tip={`Summary 16-Sep-2026 shows ${fmt(reference)}`}>Summary {fmt(reference)}</span>;
  }
  return (
    <article className={`kpi tone-${tone}`}>
      <div className="kpi-top">
        <span className="kpi-icon"><Icon name={icon} /></span>
        <h3>{label}</h3>
        {info && <span className="info" data-tip={info} tabIndex={0} aria-label={info}>i</span>}
      </div>
      <div className="kpi-value">{fmt(value)}</div>
      <div className="kpi-meter">
        <div className="meter"><i style={{ width: `${p ?? 0}%` }} /></div>
        <span className="meter-txt">{p == null ? '' : `${p < 1 && p > 0 ? p.toFixed(2) : p.toFixed(1)}% ${pctOf}`}</span>
      </div>
      <div className="kpi-foot">{badge}</div>
    </article>
  );
}
