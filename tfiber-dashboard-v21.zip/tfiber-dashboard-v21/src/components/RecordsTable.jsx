import { useDeferredValue, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import { RECORD_COLUMNS, FIELD_FILTERS, cell } from '../lib/recordColumns';
import { exportCsv, exportPdf, exportXlsx, PDF_MAX_ROWS } from '../lib/export';
import { bucketOf, enqueue, fetchStatus, getStatus, getVersion, isCheckable, subscribe } from '../lib/deviceStatus';
import { fmt } from '../lib/theme';

const PLACEHOLDER = /^(not available|not applicable|na|n\/a|#n\/a|-|need to update|yet to connect|pending|household)$/i;
const isReal = (v) => v !== '' && !PLACEHOLDER.test(v);
const TABLE_COLS = RECORD_COLUMNS.filter((c) => c.table);
const PILL = { Yes: 'good', No: 'warn', Blank: 'warn', Disconnected: 'bad', PO: 'po', POC: 'poc', UP: 'good', DOWN: 'bad', Active: 'good', 'Under Prov': 'warn', Terminated: 'bad' };
const pillClass = (v) => PILL[v] || (/^POC/i.test(v) ? 'poc' : 'neutral');
const EMPTY_FIELDS = Object.fromEntries(FIELD_FILTERS.map((f) => [f.key, '']));
const terms = (s) => s.split(/[,\n]/).map((t) => t.trim().toLowerCase()).filter(Boolean);
const STATUS_TABS = [
  ['', 'All'], ['up', 'UP'], ['down', 'DOWN'], ['other', 'Other'], ['error', 'Error / not found'], ['notchecked', 'Not checked'],
];
const power = (v) => (v == null ? '' : String(v));

/** Status cell: coloured label, Tx/Rx power, full text on hover, click to check again. */
function StatusCell({ serial }) {
  if (!isCheckable(serial)) return <span className="ph">—</span>;
  const rec = getStatus(serial);
  if (!rec) return <span className="chk"><i className="spin" /> Checking…</span>;
  const cls = rec.state === 'up' ? 'good' : rec.state === 'down' ? 'bad' : rec.state === 'other' ? 'warn' : 'neutral';
  const tip = `${rec.detail || rec.label}\nChecked ${new Date(rec.at).toLocaleTimeString()} · click to check again`;
  return (
    <button type="button" className="st-btn" title={tip} onClick={() => fetchStatus(serial, { force: true })}>
      <span className={`pill-s ${cls}`}>{rec.label}</span>
      {rec.tx != null && <small>Tx {rec.tx} · Rx {rec.rx}</small>}
    </button>
  );
}

export default function RecordsTable({ rows, context, onReload, refreshing, fetchedAt }) {
  const [fields, setFields] = useState(EMPTY_FIELDS);
  const [quick, setQuick] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sort, setSort] = useState({ key: null, dir: 1 });
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(25);
  const [menu, setMenu] = useState(false);
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState('');
  const [bulk, setBulk] = useState(null); // { done, total, failed } while "check all" runs
  const bulkRef = useRef(null);
  const menuRef = useRef(null);

  const statusVersion = useSyncExternalStore(subscribe, getVersion);
  const dFields = useDeferredValue(fields);
  const dQuick = useDeferredValue(quick);
  // only re-filter / re-sort on every status update when the result depends on the status
  const sv = statusFilter ? statusVersion : 0;
  const sortSv = sort.key === 'ontStatus' ? statusVersion : 0;

  const matched = useMemo(() => {
    const active = FIELD_FILTERS.map((f) => [f.key, terms(dFields[f.key])]).filter(([, t]) => t.length);
    const q = dQuick.trim().toLowerCase();
    if (!active.length && !q && !statusFilter) return rows;
    return rows.filter((r) => {
      for (const [k, t] of active) {
        const v = cell(r, k).toLowerCase();
        if (!t.some((x) => v.includes(x))) return false;
      }
      if (statusFilter && bucketOf(r.ont) !== statusFilter) return false;
      return !q || TABLE_COLS.some((c) => cell(r, c.key).toLowerCase().includes(q));
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, dFields, dQuick, statusFilter, sv]);

  const sorted = useMemo(() => {
    if (!sort.key) return matched;
    const k = sort.key;
    const val = (r) => (k === 'ontStatus' ? (getStatus(r.ont) || {}).label || '' : cell(r, k));
    return [...matched].sort((a, b) => val(a).localeCompare(val(b), undefined, { numeric: true, sensitivity: 'base' }) * sort.dir);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matched, sort, sortSv]);

  useEffect(() => { setPage(0); }, [rows, dFields, dQuick, statusFilter, size, sort]);
  useEffect(() => {
    if (!menu) return undefined;
    const onDoc = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenu(false); };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [menu]);

  const pages = Math.max(1, Math.ceil(sorted.length / size));
  const cur = Math.min(page, pages - 1);
  const view = useMemo(() => sorted.slice(cur * size, cur * size + size), [sorted, cur, size]);
  const activeCount = FIELD_FILTERS.filter((f) => terms(fields[f.key]).length).length + (quick.trim() ? 1 : 0) + (statusFilter ? 1 : 0);

  // the rows on screen are checked automatically (a new page / sort / filter replaces what has not started yet)
  const viewKey = view.map((r) => r.ont).join('|');
  useEffect(() => {
    const b = enqueue(view.map((r) => r.ont), 'view');
    return () => b.cancel();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewKey]);
  useEffect(() => () => { if (bulkRef.current) bulkRef.current.cancel(); }, []);

  const stats = useMemo(() => ({
    olts: new Set(matched.map((r) => r.olt).filter(isReal)).size,
    ont: matched.filter((r) => isReal(r.ont)).length,
    sid: matched.filter((r) => isReal(r.sid)).length,
    pos: new Set(matched.map((r) => r.ponum).filter(isReal)).size,
  }), [matched]);

  // status counts for the whole matching set (ignoring the status filter itself)
  const base = useMemo(() => {
    const active = FIELD_FILTERS.map((f) => [f.key, terms(dFields[f.key])]).filter(([, t]) => t.length);
    const q = dQuick.trim().toLowerCase();
    if (!active.length && !q) return rows;
    return rows.filter((r) => {
      for (const [k, t] of active) if (!t.some((x) => cell(r, k).toLowerCase().includes(x))) return false;
      return !q || TABLE_COLS.some((c) => cell(r, c.key).toLowerCase().includes(q));
    });
  }, [rows, dFields, dQuick]);
  const counts = useMemo(() => {
    const c = { '': 0, up: 0, down: 0, other: 0, error: 0, notchecked: 0 };
    const seen = new Set();
    for (const r of base) {
      const b = bucketOf(r.ont);
      if (b === 'na') continue;
      const k = String(r.ont).toUpperCase();
      if (seen.has(k)) continue; // count each device once
      seen.add(k); c[''] += 1; c[b] += 1;
    }
    return c;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [base, statusVersion]);

  const checkAll = () => {
    setMsg('');
    const serials = matched.map((r) => r.ont);
    const h = enqueue(serials, 'all', (p) => setBulk(p));
    bulkRef.current = h;
    if (!h.total) { setMsg('All matching ONT statuses are already up to date.'); return; }
    setBulk({ done: 0, total: h.total, failed: 0 });
    h.done.then((r) => {
      bulkRef.current = null; setBulk(null);
      setMsg(r.cancelled ? `Stopped after ${fmt(r.done)} of ${fmt(r.total)} checks.` : `Checked ${fmt(r.total)} ONTs${r.failed ? ` · ${fmt(r.failed)} could not be reached (see "Error / not found")` : ''}.`);
    });
  };
  const cancelAll = () => { if (bulkRef.current) bulkRef.current.cancel(); };

  const tableFilterText = [
    ...FIELD_FILTERS.filter((f) => terms(fields[f.key]).length).map((f) => `${f.label} = ${fields[f.key].trim()}`),
    ...(quick.trim() ? [`Search = ${quick.trim()}`] : []),
    ...(statusFilter ? [`ONT Status = ${STATUS_TABS.find((t) => t[0] === statusFilter)[1]}`] : []),
  ].join('; ');

  // exports include the ONT status columns (taken from the checks done so far)
  const withStatus = (r) => {
    const rec = getStatus(r.ont);
    return { ...r, ontStatus: rec ? rec.label : '', ontStatusDetail: rec ? rec.detail : '', ontTx: rec ? power(rec.tx) : '', ontRx: rec ? power(rec.rx) : '' };
  };
  const run = async (kind) => {
    setMenu(false); setMsg(''); setBusy(kind);
    try {
      const out = sorted.map(withStatus);
      if (kind === 'csv') exportCsv(out, RECORD_COLUMNS);
      else if (kind === 'xlsx') await exportXlsx(out, RECORD_COLUMNS);
      else {
        const info = await exportPdf(out, RECORD_COLUMNS.filter((c) => c.pdf), { title: 'T-Fiber Connectivity · Records', subtitle: `${context}${tableFilterText ? ` · Table filters: ${tableFilterText}` : ''}` });
        if (info.capped) setMsg(`PDF holds the first ${fmt(info.used)} of ${fmt(info.total)} records. Use CSV or Excel for the full list.`);
      }
      const missing = new Set(sorted.filter((r) => bucketOf(r.ont) === 'notchecked').map((r) => String(r.ont).toUpperCase())).size;
      if (missing) setMsg((m) => `${m ? `${m} ` : ''}${fmt(missing)} ONT${missing === 1 ? ' has' : 's have'} no status in the file yet. Use “Check ONT status” first to include them.`);
    } catch (e) {
      setMsg(`Export failed: ${e.message}`);
    } finally { setBusy(''); }
  };

  const setField = (k, v) => setFields((p) => ({ ...p, [k]: v }));
  const clear = () => { setFields(EMPTY_FIELDS); setQuick(''); setStatusFilter(''); };
  const toggleSort = (k) => setSort((s) => (s.key !== k ? { key: k, dir: 1 } : s.dir === 1 ? { key: k, dir: -1 } : { key: null, dir: 1 }));
  const toCheck = counts.notchecked + counts.error; // devices that still need a (new) check

  return (
    <section className="card records">
      <header className="card-head">
        <h2>Records</h2>
        <div className="rec-actions">
          <input className="search" placeholder="Search all columns…" value={quick} onChange={(e) => setQuick(e.target.value)} />
          {fetchedAt && <span className="rec-updated" title="When the records were last read from the services API">Updated {new Date(fetchedAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>}
          {onReload && <button type="button" className="btn" onClick={onReload} disabled={refreshing} title="Read the latest records from the API">{refreshing ? 'Refreshing…' : 'Reload data'}</button>}
          <div className="menu-wrap" ref={menuRef}>
            <button className="btn primary" disabled={!sorted.length || !!busy} onClick={() => setMenu((m) => !m)} aria-expanded={menu}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v12M7 10l5 5 5-5M4 20h16" /></svg>
              {busy ? 'Preparing…' : `Export ${fmt(sorted.length)}`}
            </button>
            {menu && (
              <div className="menu" role="menu">
                <button role="menuitem" onClick={() => run('csv')}><b>CSV</b><span>All columns · opens in Excel</span></button>
                <button role="menuitem" onClick={() => run('xlsx')}><b>Excel (.xlsx)</b><span>All columns · IDs kept as text</span></button>
                <button role="menuitem" onClick={() => run('pdf')}><b>PDF</b><span>Key columns · up to {fmt(PDF_MAX_ROWS)} rows</span></button>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="rec-filters">
        {FIELD_FILTERS.map((f) => (
          <label key={f.key} className={terms(fields[f.key]).length ? 'on' : ''}>
            <span>{f.label}</span>
            <input value={fields[f.key]} placeholder={f.placeholder} onChange={(e) => setField(f.key, e.target.value)} spellCheck={false} />
          </label>
        ))}
        <button className="btn ghost" disabled={!activeCount} onClick={clear}>Clear{activeCount ? ` (${activeCount})` : ''}</button>
      </div>
      <p className="rec-hint">Separate several values with a comma to match any of them.</p>

      <div className="rec-stats">
        <div><b>{fmt(matched.length)}</b><span>Matching records</span></div>
        <div><b>{fmt(stats.pos)}</b><span>Distinct PO numbers</span></div>
        <div><b>{fmt(stats.olts)}</b><span>Distinct OLT IPs</span></div>
        <div><b>{fmt(stats.ont)}</b><span>With ONT serial</span></div>
        <div><b>{fmt(stats.sid)}</b><span>With Service ID</span></div>
      </div>

      <div className="status-bar">
        <div className="seg-s" role="group" aria-label="Filter by ONT status">
          <span className="seg-label">ONT status</span>
          {STATUS_TABS.map(([k, label]) => (
            <button key={k || 'all'} className={`${statusFilter === k ? 'on' : ''} ${k}`} onClick={() => setStatusFilter(k)}>
              {label} <b>{fmt(counts[k])}</b>
            </button>
          ))}
        </div>
        <div className="bulk">
          {bulk ? (
            <>
              <div className="bar-prog" role="progressbar" aria-valuenow={bulk.done} aria-valuemax={bulk.total}><i style={{ width: `${bulk.total ? (bulk.done / bulk.total) * 100 : 0}%` }} /></div>
              <span className="muted">{fmt(bulk.done)} / {fmt(bulk.total)}{bulk.failed ? ` · ${fmt(bulk.failed)} failed` : ''}</span>
              <button className="btn sm" onClick={cancelAll}>Stop</button>
            </>
          ) : (
            <button className="btn sm" onClick={checkAll} disabled={!counts[''] || !!bulk} data-tip="Calls the device-status API for every matching ONT serial that starts with TJ and has no current status">
              Check ONT status{toCheck ? ` (${fmt(toCheck)})` : ''}
            </button>
          )}
        </div>
      </div>

      {msg && <div className="notice slim">{msg}</div>}

      <div className="table-wrap rec-wrap">
        <table className="rec">
          <thead>
            <tr>
              {TABLE_COLS.map((c) => (
                <th key={c.key} onClick={() => toggleSort(c.key)} aria-sort={sort.key === c.key ? (sort.dir === 1 ? 'ascending' : 'descending') : 'none'}>
                  {c.label}<span className="sort">{sort.key === c.key ? (sort.dir === 1 ? '▲' : '▼') : ''}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {view.map((r, i) => (
              <tr key={`${cur}-${i}`}>
                {TABLE_COLS.map((c) => {
                  if (c.status) return <td key={c.key} className="st-td"><StatusCell serial={r.ont} /></td>;
                  const v = cell(r, c.key);
                  if (c.pill || c.key === 'po') return <td key={c.key}>{v ? <span className={`pill-s ${pillClass(v)}`}>{v}</span> : <span className="ph">—</span>}</td>;
                  return <td key={c.key} className={!v || PLACEHOLDER.test(v) ? 'ph' : ''} title={v}>{v || '—'}</td>;
                })}
              </tr>
            ))}
            {view.length === 0 && <tr><td colSpan={TABLE_COLS.length} className="no-rows">No records match these filters.</td></tr>}
          </tbody>
        </table>
      </div>

      <footer className="pager">
        <span className="muted">
          {sorted.length ? `${fmt(cur * size + 1)}–${fmt(Math.min(sorted.length, cur * size + size))} of ${fmt(sorted.length)}` : '0 records'}
        </span>
        <div className="pager-ctl">
          <label>Rows <select value={size} onChange={(e) => setSize(+e.target.value)}>{[25, 50, 100, 200].map((n) => <option key={n}>{n}</option>)}</select></label>
          <button className="btn sm" disabled={cur === 0} onClick={() => setPage(0)}>«</button>
          <button className="btn sm" disabled={cur === 0} onClick={() => setPage(cur - 1)}>‹ Prev</button>
          <span className="page-no">Page {fmt(cur + 1)} / {fmt(pages)}</span>
          <button className="btn sm" disabled={cur >= pages - 1} onClick={() => setPage(cur + 1)}>Next ›</button>
          <button className="btn sm" disabled={cur >= pages - 1} onClick={() => setPage(pages - 1)}>»</button>
        </div>
      </footer>
    </section>
  );
}
